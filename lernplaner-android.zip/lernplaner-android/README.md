# Lernplaner – native Android-App (Kotlin)

Diese Version ist eine native Android-App und arbeitet direkt mit dem Android-Kalenderspeicher. Es gibt keine ICS-URL und keinen Cloudserver.

## Enthalten
- Aufgaben lokal auf dem Gerät speichern (Titel, Fach, Dauer, Priorität und Deadline in Tagen)
- Android-Kalendertermine lesen (Kalenderberechtigung erforderlich)
- Schreibbaren Zielkalender auswählen
- Lernblöcke in freie Zeitfenster einplanen
- Lernblöcke als normale Termine in den ausgewählten Android-Kalender schreiben
- Hintergrund-Neuplanung über WorkManager (Android darf Jobs verzögern; Intervall mindestens 15 Minuten)
- APK-Build über Android Studio oder GitHub Actions

## APK bauen
Der Build dieser Umgebung hat keinen Android SDK installiert, daher wurde hier keine APK kompiliert. Der vollständige Android-Studio-Projektcode ist enthalten.

### Mit Android Studio
1. ZIP entpacken.
2. Android Studio öffnen und `lernplaner-android` als Projekt öffnen.
3. JDK 17 auswählen, Gradle-Synchronisierung abwarten und Android SDK Platform 35 installieren.
4. Menü **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Die Debug-APK liegt danach üblicherweise unter `app/build/outputs/apk/debug/app-debug.apk`.

### APK per GitHub Actions bauen
1. Lege ein privates oder öffentliches GitHub-Repository an und lade den Projektinhalt hoch.
2. Die Workflow-Datei `.github/workflows/build-apk.yml` baut bei jedem Push eine Debug-APK.
3. In GitHub unter **Actions → Android APK build → Artifacts** die `lernplaner-debug-apk` herunterladen.

## Installation
Die Debug-APK auf das Android-Gerät kopieren und öffnen. Android kann nach Erlaubnis zum Installieren aus dieser Quelle fragen.

## Kalender-Verhalten
- Die App liest Termine aus dem Android Calendar Provider.
- Du wählst den Kalender aus, in den Lernblöcke geschrieben werden. Nicht jeder Anbieter stellt einen rein lokalen, offline bleibenden Kalender bereit; wähle einen ausdrücklich lokalen Kalender, wenn dein Kalenderanbieter einen anbietet.
- Die App erstellt und aktualisiert nur Termine, die sie mit der Beschreibung `lernplaner:auto` markiert. Sie löscht beim Neuplanen ausschließlich zukünftige, von ihr markierte Lerntermine im ausgewählten Zielkalender.
- Die App fragt beim ersten Start nach Kalenderberechtigungen.
- Androids Hintergrundausführung ist nicht minutengenau. WorkManager führt wiederkehrende Arbeit ungefähr regelmäßig aus, aber das Betriebssystem kann sie verschieben.
- MVP-Planung: werktags 15:00–20:00, am Wochenende 10:00–18:00; Planungsfenster sieben Tage. Das lässt sich im Quellcode anpassen.
- Dies ist ein MVP und wurde nicht auf allen Kalender-Apps/Herstellervarianten getestet. Sichere wichtige Kalenderdaten vor dem Testen.

## Technischer Stack
- Kotlin
- Jetpack Compose
- Android Calendar Provider (`CalendarContract`)
- WorkManager
- SharedPreferences / JSON für lokale Aufgaben
