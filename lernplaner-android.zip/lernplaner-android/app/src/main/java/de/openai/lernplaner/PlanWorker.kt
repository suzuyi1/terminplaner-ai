package de.openai.lernplaner

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PlanWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            if (!CalendarPlanner.permissionsGranted(applicationContext)) return@withContext Result.success()
            val calendarId = TaskStore.targetCalendar(applicationContext)
            if (calendarId < 0) return@withContext Result.success()
            CalendarPlanner.writePlan(applicationContext, calendarId, TaskStore.load(applicationContext))
            Result.success()
        } catch (_: SecurityException) {
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
