package de.openai.lernplaner

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF172554)
private val Blue = Color(0xFF3559D8)
private val Pale = Color(0xFFE9EFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        scheduleWorker()
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Navy)) { PlannerScreen() } }
    }
    private fun scheduleWorker() {
        val request = PeriodicWorkRequestBuilder<PlanWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("lernplaner-background", ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var tasks by remember { mutableStateOf(TaskStore.load(context).toList()) }
    var calendars by remember { mutableStateOf(emptyList<CalendarChoice>()) }
    var selectedCalendar by remember { mutableStateOf(TaskStore.targetCalendar(context)) }
    var expanded by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("60") }
    var priority by remember { mutableStateOf("Mittel") }
    var deadlineDays by remember { mutableStateOf("3") }
    var message by remember { mutableStateOf("Deine Daten bleiben auf diesem Gerät.") }
    var planning by remember { mutableStateOf(false) }
    var plannedCount by remember { mutableIntStateOf(0) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) {
            calendars = CalendarPlanner.calendars(context)
            if (selectedCalendar < 0 && calendars.isNotEmpty()) {
                val default = calendars.firstOrNull { it.isLocal } ?: calendars.first()
                selectedCalendar = default.id
                TaskStore.setTargetCalendar(context, default.id)
            }
            message = if (calendars.isEmpty()) "Kein beschreibbarer Kalender gefunden." else "Kalenderzugriff aktiviert."
        } else message = "Bitte Kalenderzugriff erlauben, damit die App Termine lesen und schreiben kann."
    }

    LaunchedEffect(Unit) {
        if (CalendarPlanner.permissionsGranted(context)) {
            calendars = CalendarPlanner.calendars(context)
            if (selectedCalendar < 0 && calendars.isNotEmpty()) {
                val default = calendars.firstOrNull { it.isLocal } ?: calendars.first()
                selectedCalendar = default.id
                TaskStore.setTargetCalendar(context, default.id)
            }
        } else {
            permissionLauncher.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR))
        }
    }

    fun saveTasks(newTasks: List<StudyTask>) {
        tasks = newTasks
        TaskStore.save(context, newTasks)
    }
    fun runPlan() {
        if (!CalendarPlanner.permissionsGranted(context)) {
            permissionLauncher.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR))
            return
        }
        if (selectedCalendar < 0) { message = "Bitte zuerst einen Zielkalender auswählen."; return }
        planning = true
        scope.launch {
            try {
                val count = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    CalendarPlanner.writePlan(context, selectedCalendar, tasks)
                }
                plannedCount = count
                message = "$count Lernblöcke in den Kalender geschrieben."
            } catch (e: Exception) {
                message = "Planung fehlgeschlagen: ${e.message ?: "Unbekannter Fehler"}"
            } finally { planning = false }
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Lernplaner", fontWeight = FontWeight.Bold)
                    Text("Dein lokaler Lernkalender", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                } },
                actions = { IconButton(onClick = { runPlan() }) { Icon(Icons.Default.Refresh, contentDescription = "Neu planen") } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().background(Color(0xFFF5F7FB)).padding(padding),
            contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(24.dp)) {
                    Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Hallo! 👋", style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text("${tasks.count { !it.done }} offene Aufgaben", color = Color(0xFFDDE5FF))
                            Text("Planung bleibt auf deinem Handy.", color = Color(0xFFDDE5FF), style = MaterialTheme.typography.bodySmall)
                        }
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = Color(0xFFB9C8FF), modifier = Modifier.size(44.dp))
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Kalender", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Wähle, in welchen Android-Kalender die Lernblöcke geschrieben werden.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        if (calendars.isEmpty()) {
                            OutlinedButton(onClick = { permissionLauncher.launch(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)) }) {
                                Text("Kalenderzugriff erlauben")
                            }
                        } else {
                            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                                OutlinedTextField(
                                    value = calendars.firstOrNull { it.id == selectedCalendar }?.let {
                                        it.name + if (it.isLocal) " · lokal" else " · ${it.account}"
                                    } ?: "Kalender auswählen",
                                    onValueChange = {}, readOnly = true, label = { Text("Zielkalender") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                                    modifier = Modifier.menuAnchor().fillMaxWidth()
                                )
                                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    calendars.forEach { cal ->
                                        DropdownMenuItem(
                                            text = { Text(cal.name + if (cal.isLocal) " · lokal" else " · ${cal.account}") },
                                            onClick = {
                                                selectedCalendar = cal.id
                                                TaskStore.setTargetCalendar(context, cal.id)
                                                expanded = false
                                                message = "Zielkalender geändert. Tippe auf „Plan erstellen“."
                                            }
                                        )
                                    }
                                }
                            }
                        }
                        Text(message, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                }
            }
            item {
                Card(shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Neue Lernaufgabe", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(title, { title = it }, label = { Text("Aufgabe *") }, placeholder = { Text("z. B. Bio: Zellorganellen") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(subject, { subject = it }, label = { Text("Fach") }, placeholder = { Text("Biologie") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit).take(4) }, label = { Text("Dauer in Minuten") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(deadlineDays, { deadlineDays = it.filter(Char::isDigit).take(3) }, label = { Text("Deadline in Tagen") }, supportingText = { Text("Ab heute gerechnet, z. B. 3") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        var prExpanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = prExpanded, onExpandedChange = { prExpanded = !prExpanded }) {
                            OutlinedTextField(priority, {}, readOnly = true, label = { Text("Priorität") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(prExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded = prExpanded, onDismissRequest = { prExpanded = false }) {
                                listOf("Hoch", "Mittel", "Niedrig").forEach { p -> DropdownMenuItem(text = { Text(p) }, onClick = { priority = p; prExpanded = false }) }
                            }
                        }
                        Button(
                            onClick = {
                                val mins = minutes.toIntOrNull() ?: 60
                                if (title.isBlank()) { message = "Bitte gib der Aufgabe einen Titel."; return@Button }
                                if (mins !in 15..1200) { message = "Die Dauer muss zwischen 15 und 1200 Minuten liegen."; return@Button }
                                val days = (deadlineDays.toIntOrNull() ?: 3).coerceIn(1, 180)
                                val task = StudyTask(title = title.trim(), subject = subject.trim(), minutes = mins, priority = priority,
                                    deadlineMillis = System.currentTimeMillis() + days * 24L * 60 * 60 * 1000)
                                saveTasks(tasks + task)
                                title = ""; subject = ""; minutes = "60"; deadlineDays = "3"; message = "Aufgabe gespeichert. Tippe auf „Plan erstellen“."
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("＋ Aufgabe hinzufügen") }
                    }
                }
            }
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Deine Aufgaben", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Termine werden in 30–60-Minuten-Blöcke aufgeteilt.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Text("${tasks.size}", color = Blue, fontWeight = FontWeight.Bold)
                }
            }
            if (tasks.isEmpty()) {
                item { Text("Noch keine Aufgaben. Lege oben deine erste Lernaufgabe an.", color = Color.Gray, modifier = Modifier.padding(8.dp)) }
            } else {
                items(tasks, key = { it.id }) { task ->
                    Card(shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(task.title, fontWeight = FontWeight.SemiBold)
                                Text("${task.subject.ifBlank { "Ohne Fach" }} · ${task.minutes} Min. · ${task.priority}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                                if (task.done) Text("Erledigt", color = Color(0xFF18794E), style = MaterialTheme.typography.labelSmall)
                            }
                            IconButton(onClick = { saveTasks(tasks.map { if (it.id == task.id) it.copy(done = !it.done) else it }) }) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Erledigt", tint = if (task.done) Color(0xFF18794E) else Color.Gray)
                            }
                            IconButton(onClick = { saveTasks(tasks.filterNot { it.id == task.id }); message = "Aufgabe gelöscht. Bereits erzeugte Kalendertermine werden beim nächsten Planen aktualisiert." }) {
                                Icon(Icons.Default.Delete, contentDescription = "Löschen", tint = Color(0xFFB42318))
                            }
                        }
                    }
                }
            }
            item {
                Button(onClick = { runPlan() }, enabled = !planning, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                    if (planning) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                    else Icon(Icons.Default.CalendarMonth, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (planning) "Plane deinen Kalender …" else "Plan erstellen / aktualisieren")
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Pale), shape = RoundedCornerShape(16.dp)) {
                    Text(
                        "Hinweis: Die automatische Planung läuft im Hintergrund, Android kann sie verzögern. Bei Änderungen kannst du jederzeit oben auf ↻ tippen. Lernzeiten: Mo–Fr 15–20 Uhr, Wochenende 10–18 Uhr.",
                        modifier = Modifier.padding(14.dp), color = Navy, style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}
