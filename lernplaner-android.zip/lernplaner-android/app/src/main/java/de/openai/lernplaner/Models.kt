package de.openai.lernplaner

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class StudyTask(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val subject: String = "",
    val minutes: Int = 60,
    val deadlineMillis: Long = System.currentTimeMillis() + 3 * 24 * 60 * 60 * 1000L,
    val priority: String = "Mittel",
    val done: Boolean = false
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("title", title); put("subject", subject)
        put("minutes", minutes); put("deadlineMillis", deadlineMillis)
        put("priority", priority); put("done", done)
    }
    companion object {
        fun fromJson(o: JSONObject) = StudyTask(
            id = o.optString("id", UUID.randomUUID().toString()),
            title = o.optString("title", "Aufgabe"),
            subject = o.optString("subject", ""),
            minutes = o.optInt("minutes", 60),
            deadlineMillis = o.optLong("deadlineMillis", System.currentTimeMillis() + 86400000),
            priority = o.optString("priority", "Mittel"),
            done = o.optBoolean("done", false)
        )
    }
}

data class CalendarChoice(val id: Long, val name: String, val account: String, val isLocal: Boolean)

object TaskStore {
    private const val PREFS = "lernplaner_local"
    private const val TASKS = "tasks"
    private const val CALENDAR_ID = "target_calendar_id"
    fun load(context: android.content.Context): MutableList<StudyTask> {
        val raw = context.getSharedPreferences(PREFS, 0).getString(TASKS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return MutableList(arr.length()) { i -> StudyTask.fromJson(arr.getJSONObject(i)) }
    }
    fun save(context: android.content.Context, tasks: List<StudyTask>) {
        val arr = JSONArray()
        tasks.forEach { arr.put(it.toJson()) }
        context.getSharedPreferences(PREFS, 0).edit().putString(TASKS, arr.toString()).apply()
    }
    fun targetCalendar(context: android.content.Context): Long =
        context.getSharedPreferences(PREFS, 0).getLong(CALENDAR_ID, -1L)
    fun setTargetCalendar(context: android.content.Context, id: Long) {
        context.getSharedPreferences(PREFS, 0).edit().putLong(CALENDAR_ID, id).apply()
    }
}
