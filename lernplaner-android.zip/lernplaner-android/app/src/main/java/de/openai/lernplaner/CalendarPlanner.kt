package de.openai.lernplaner

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat
import java.time.*
import java.util.TimeZone

object CalendarPlanner {
    private val zone: ZoneId = ZoneId.systemDefault()
    private const val MARKER = "lernplaner:auto"

    fun permissionsGranted(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun calendars(context: Context): List<CalendarChoice> {
        if (!permissionsGranted(context)) return emptyList()
        val result = mutableListOf<CalendarChoice>()
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
            CalendarContract.Calendars.ACCOUNT_NAME,
            CalendarContract.Calendars.ACCOUNT_TYPE,
            CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL
        )
        context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI, projection,
            "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ?",
            arrayOf(CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR.toString()),
            CalendarContract.Calendars.CALENDAR_DISPLAY_NAME + " ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val name = c.getString(1) ?: "Kalender"
                val account = c.getString(2) ?: ""
                val type = c.getString(3) ?: ""
                val local = type.equals("LOCAL", true) || (account.isBlank() && type.isBlank())
                result += CalendarChoice(id, name, account, local)
            }
        }
        return result
    }

    data class Busy(val start: Long, val end: Long)
    data class Block(val task: StudyTask, val start: Long, val end: Long)

    private fun busyEvents(context: Context, start: Long, end: Long): List<Busy> {
        val result = mutableListOf<Busy>()
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
            .appendPath(start.toString()).appendPath(end.toString()).build()
        val projection = arrayOf(CalendarContract.Instances.BEGIN, CalendarContract.Instances.END)
        context.contentResolver.query(uri, projection, null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
            while (c.moveToNext()) {
                val s = c.getLong(0); val e = c.getLong(1)
                if (e > s) result += Busy(s, e)
            }
        }
        return result.sortedBy { it.start }
    }

    fun plan(context: Context, tasks: List<StudyTask>): List<Block> {
        val now = System.currentTimeMillis()
        val horizon = now + 7L * 24 * 60 * 60 * 1000
        val busy = busyEvents(context, now, horizon).toMutableList()
        val slots = mutableListOf<Busy>()
        var day = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        val lastDay = Instant.ofEpochMilli(horizon).atZone(zone).toLocalDate()
        while (!day.isAfter(lastDay)) {
            val weekend = day.dayOfWeek == DayOfWeek.SATURDAY || day.dayOfWeek == DayOfWeek.SUNDAY
            val startHour = if (weekend) 10 else 15
            val endHour = if (weekend) 18 else 20
            var cursor = day.atTime(startHour, 0).atZone(zone).toInstant().toEpochMilli()
            val finish = day.atTime(endHour, 0).atZone(zone).toInstant().toEpochMilli()
            if (cursor < now) cursor = now
            if (finish > cursor) {
                val dailyBusy = busy.filter { it.start < finish && it.end > cursor }.sortedBy { it.start }
                for (b in dailyBusy) {
                    if (b.start > cursor) slots += Busy(cursor, minOf(b.start, finish))
                    cursor = maxOf(cursor, b.end)
                    if (cursor >= finish) break
                }
                if (cursor < finish) slots += Busy(cursor, finish)
            }
            day = day.plusDays(1)
        }
        val blocks = mutableListOf<Block>()
        val sortedTasks = tasks.filter { !it.done }.sortedWith(
            compareBy<StudyTask> { it.deadlineMillis }
                .thenBy { when (it.priority) { "Hoch" -> 0; "Niedrig" -> 2; else -> 1 } }
        )
        for (task in sortedTasks) {
            var remaining = task.minutes
            val deadline = task.deadlineMillis
            val iterator = slots.listIterator()
            while (iterator.hasNext() && remaining > 0) {
                val slot = iterator.next()
                if (slot.start >= deadline || slot.end <= now) continue
                val start = maxOf(slot.start, now)
                val available = ((slot.end - start) / 60000L).toInt()
                if (available < 25) continue
                val chunk = minOf(remaining, 60, available)
                if (chunk < 25 && remaining > chunk) continue
                val end = start + chunk * 60000L
                blocks += Block(task, start, end)
                remaining -= chunk
                if (end < slot.end) iterator.set(Busy(end, slot.end)) else iterator.remove()
            }
        }
        return blocks
    }

    fun writePlan(context: Context, calendarId: Long, tasks: List<StudyTask>): Int {
        if (!permissionsGranted(context)) throw SecurityException("Kalenderberechtigungen fehlen.")
        val now = System.currentTimeMillis()
        // Remove only future events generated by this app in the selected target calendar.
        val projection = arrayOf(CalendarContract.Events._ID)
        context.contentResolver.query(
            CalendarContract.Events.CONTENT_URI, projection,
            "${CalendarContract.Events.CALENDAR_ID}=? AND ${CalendarContract.Events.DTSTART}>=? AND ${CalendarContract.Events.DESCRIPTION} LIKE ?",
            arrayOf(calendarId.toString(), now.toString(), "%$MARKER%"),
            null
        )?.use { c ->
            val ids = mutableListOf<Long>()
            while (c.moveToNext()) ids += c.getLong(0)
            ids.forEach { id ->
                context.contentResolver.delete(
                    CalendarContract.Events.CONTENT_URI.buildUpon().appendPath(id.toString()).build(),
                    null, null
                )
            }
        }
        val plan = plan(context, tasks)
        plan.forEach { block ->
            val values = ContentValues().apply {
                put(CalendarContract.Events.CALENDAR_ID, calendarId)
                put(CalendarContract.Events.TITLE, "Lernen: ${block.task.title}")
                put(CalendarContract.Events.DESCRIPTION, "$MARKER\nAufgabe: ${block.task.title}\nFach: ${block.task.subject}")
                put(CalendarContract.Events.DTSTART, block.start)
                put(CalendarContract.Events.DTEND, block.end)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
                put(CalendarContract.Events.HAS_ALARM, 0)
            }
            context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
        }
        return plan.size
    }
}
